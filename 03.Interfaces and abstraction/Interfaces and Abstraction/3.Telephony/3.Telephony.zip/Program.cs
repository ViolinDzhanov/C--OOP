﻿using _3.Telephony.Core;
using _3.Telephony.Core.Interfaces;
using _3.Telephony.IO;

Iengine engine = new Enginne(new ConsoleReader(), new ConsoleWriter());

engine.Run();